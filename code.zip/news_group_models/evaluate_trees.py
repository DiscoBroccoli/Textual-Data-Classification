
import matplotlib.pyplot as plt
import news_group
import evaluation
import pickle
import numpy as np

# get the train-test data
X_train, y_train, X_test, y_test = news_group.fetch_data()

dt = pickle.load(open("dt_20groups.model", "rb"))
evaluation.evaluate_model(dt, X_train, y_train, X_test, y_test)


# Validation Curves
# Setup plot

plt.title("Accuracy vs Max depth for Decision Trees and Ensemble methods")

plt.xlim(100, 1000)
plt.xlabel('max depth')
plt.ylabel("Accuracy")
evaluation.plot_validation_curve(dt, "Decision Trees", X_train, y_train, "max_depth", np.linspace(100, 1000, 11, dtype=int), plot_number=1)

plt.legend(loc="best")

plt.show()
